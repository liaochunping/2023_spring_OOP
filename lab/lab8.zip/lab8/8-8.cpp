#include <iostream>
#include <vector>
using namespace std;

class ChessPiece {
public:
    ChessPiece() : color('W'), position(make_pair(0, 0)) {
        cout << "Default constructor" << endl;
    }
    ChessPiece(char c, pair<int, int> pos) : color(c), position(pos) {
        cout << "Non-default constructor" << endl;
    }
    ChessPiece(const ChessPiece& other) : color(other.color), position(other.position) {
        cout << "Copy constructor" << endl;
    }
    ChessPiece& operator=(const ChessPiece& other) {
        if (this == &other) {
            return *this;
        }
        color = other.color;
        position = other.position;
        cout << "Copy assignment operator" << endl;
        return *this;
    }
    ChessPiece(ChessPiece&& other) : color(other.color), position(other.position) {
        other.color = 'W';
        other.position = make_pair(0, 0);
        cout << "Move constructor" << endl;
    }
    ChessPiece& operator=(ChessPiece&& other) {
        if (this == &other) {
            return *this;
        }
        color = other.color;
        position = other.position;
        other.color = 'W';
        other.position = make_pair(0, 0);
        cout << "Move assignment operator" << endl;
        return *this;
    }
    ~ChessPiece() {
        // cout << "Destructor" << endl;
    }

    void print(string s) {
        cout << s << " => color: " << color << ", position: <" << position.first << ", " << position.second << ">" << endl;    
    }

private:
    char color;
    pair<int, int> position;
};

int main() {
    // Create a ChessPiece with default constructor
    ChessPiece p1;
    p1.print("p1");
    
    cout << "----------------" << endl;

    // Create a ChessPiece with non-default constructor
    ChessPiece p2('B', make_pair(5, 7));
    p2.print("p2");

    cout << "----------------" << endl;

    // Test copy constructor
    ChessPiece p3 = p2;
    p3.print("p3");
    
    cout << "----------------" << endl;

    // Test copy assignment operator
    ChessPiece p4('W', make_pair(2, 2));
    p4 = p2;
    p4.print("p4");
    
    cout << "----------------" << endl;

    // Test move constructor
    ChessPiece p5 = std::move(p4);
    p5.print("p5");
    p4.print("p4 after move: ");
    
    cout << "----------------" << endl;

    // Test move assignment operator
    ChessPiece p6;
    p6 = std::move(p5);
    p6.print("p6");
    p5.print("p5 after move: ");

    return 0;
}
