#ifndef TRIANGLE_H
#define TRIANGLE_H

#include "Vertex.h"
struct Triangle
{
	Vertex a;
	Vertex b;
	Vertex c;
	bool right;
};

#endif